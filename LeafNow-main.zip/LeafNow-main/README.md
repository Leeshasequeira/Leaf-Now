# Leaf Now
A completely responsive full stack website for buying/selling/donating plants/seeds.
